NUMBER COUNTER — iPhone Web App

Use:
1. index.html ko Safari me open karein.
2. Example: 70,75,79,34,20,65,60(30)
3. ADD dabayein.
4. Same numbers ki quantity automatically add hoti hai.
5. TOTAL automatically update hota hai.
6. Safari Share -> Add to Home Screen se Home Screen icon bana sakte hain.

Note: This is a client-side prototype; data browser ke local storage me save hota hai.
